// The exported code uses Tailwind CSS. Install Tailwind CSS in your dev environment to ensure all styles work.
import React, { useState, useEffect, useRef } from 'react';
import * as echarts from 'echarts';
const App: React.FC = () => {
const [selectedCompany, setSelectedCompany] = useState<string>('All');
const [chatMessages, setChatMessages] = useState<Array<{type: string; message: string}>>([]);
const [chatInput, setChatInput] = useState<string>('');
const [showChatbot, setShowChatbot] = useState<boolean>(true);
const [locationFilters, setLocationFilters] = useState({
remote: false,
onsite: false,
hybrid: false
});
const barChartRef = useRef<HTMLDivElement>(null);
const pieChartRef = useRef<HTMLDivElement>(null);
const lineChartRef = useRef<HTMLDivElement>(null);
const companies = ['All', 'Google', 'Meta', 'Amazon', 'Apple', 'Netflix'];
const allJobListings = [
{
id: 1,
company: 'Google',
title: 'Senior Machine Learning Engineer',
location: 'Mountain View, CA',
type: 'Full-time',
posted: '2 days ago',
salary: '$180,000 - $250,000',
workType: 'onsite'
},
{
id: 2,
company: 'Meta',
title: 'Product Designer',
location: 'Remote',
type: 'Full-time',
posted: '1 day ago',
salary: '$140,000 - $200,000',
workType: 'remote'
},
{
id: 3,
company: 'Amazon',
title: 'Software Development Engineer III',
location: 'Seattle, WA',
type: 'Full-time',
posted: '3 days ago',
salary: '$160,000 - $220,000',
workType: 'hybrid'
}
];
const [jobListings, setJobListings] = useState(allJobListings);
useEffect(() => {
filterJobs();
}, [locationFilters]);
const filterJobs = () => {
const activeFilters = Object.entries(locationFilters)
.filter(([_, isActive]) => isActive)
.map(([key]) => key);
if (activeFilters.length === 0) {
setJobListings(allJobListings);
} else {
const filtered = allJobListings.filter(job =>
activeFilters.includes(job.workType)
);
setJobListings(filtered);
}
updateCharts(jobListings);
};
const handleLocationFilter = (filterType: 'remote' | 'onsite' | 'hybrid') => {
setLocationFilters(prev => ({
...prev,
[filterType]: !prev[filterType]
}));
};
const updateCharts = (filteredJobs: typeof allJobListings) => {
if (barChartRef.current) initBarChart(filteredJobs);
if (pieChartRef.current) initPieChart(filteredJobs);
if (lineChartRef.current) initLineChart(filteredJobs);
};
useEffect(() => {
initBarChart(jobListings);
initPieChart(jobListings);
initLineChart(jobListings);
}, []);
const initBarChart = (jobs: typeof allJobListings) => {
const chart = echarts.init(barChartRef.current);
const option = {
animation: false,
title: {
text: 'Jobs by Company',
left: 'center',
textStyle: {
fontSize: 16
}
},
xAxis: {
type: 'category',
data: ['Google', 'Meta', 'Amazon', 'Apple', 'Netflix']
},
yAxis: {
type: 'value'
},
series: [{
data: [120, 90, 150, 80, 40],
type: 'bar',
barWidth: '40%',
itemStyle: {
color: '#4F46E5'
}
}]
};
chart.setOption(option);
};
const initPieChart = (jobs: typeof allJobListings) => {
const chart = echarts.init(pieChartRef.current);
const option = {
animation: false,
title: {
text: 'Jobs by Category',
left: 'center',
textStyle: {
fontSize: 16
}
},
series: [{
type: 'pie',
radius: '65%',
data: [
{ value: 35, name: 'Engineering' },
{ value: 20, name: 'Design' },
{ value: 25, name: 'Product' },
{ value: 15, name: 'Data Science' },
{ value: 5, name: 'Other' }
],
emphasis: {
itemStyle: {
shadowBlur: 10,
shadowOffsetX: 0,
shadowColor: 'rgba(0, 0, 0, 0.5)'
}
}
}]
};
chart.setOption(option);
};
const initLineChart = (jobs: typeof allJobListings) => {
const chart = echarts.init(lineChartRef.current);
const option = {
animation: false,
title: {
text: 'Hiring Trends',
left: 'center',
textStyle: {
fontSize: 16
}
},
xAxis: {
type: 'category',
data: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun']
},
yAxis: {
type: 'value'
},
series: [{
data: [150, 230, 224, 218, 135, 147],
type: 'line',
smooth: true,
itemStyle: {
color: '#4F46E5'
}
}]
};
chart.setOption(option);
};
const handleChatSubmit = (e: React.FormEvent) => {
e.preventDefault();
if (!chatInput.trim()) return;
setChatMessages([...chatMessages,
{ type: 'user', message: chatInput },
{ type: 'ai', message: 'I am analyzing the job market trends. Based on the current data, there are numerous opportunities in machine learning and software development at FAANG companies.' }
]);
setChatInput('');
};
return (
<div className="min-h-screen bg-gray-50">
{/* Header */}
<header className="bg-white shadow-sm">
<div className="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between">
<div className="flex items-center space-x-4">
<h1 className="text-2xl font-bold text-indigo-600">AI Job Explorer</h1>
<nav className="hidden md:flex space-x-8 ml-12">
<a href="https://readdy.ai/home/0d0b1e85-32e8-4a2a-8c48-0289aa4e8ce0/8d3cc41f-618b-4b87-a29b-354f8aa20374" data-readdy="true" className="text-gray-700 hover:text-indigo-600 cursor-pointer">Dashboard</a>
<a href="#" className="text-gray-700 hover:text-indigo-600 cursor-pointer">Analytics</a>
<a href="#" className="text-gray-700 hover:text-indigo-600 cursor-pointer">Saved Jobs</a>
</nav>
</div>
<div className="flex items-center space-x-4">
<div className="relative">
<input
type="text"
placeholder="Search jobs..."
className="w-64 px-4 py-2 rounded-lg border-gray-200 focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
/>
<i className="fas fa-search absolute right-3 top-3 text-gray-400"></i>
</div>
<button className="p-2 rounded-full hover:bg-gray-100 cursor-pointer">
<i className="fas fa-bell text-gray-600"></i>
</button>
<button className="p-2 rounded-full hover:bg-gray-100 cursor-pointer">
<i className="fas fa-user-circle text-gray-600 text-2xl"></i>
</button>
</div>
</div>
</header>
<main className="max-w-7xl mx-auto px-4 py-8">
<div className="grid grid-cols-12 gap-8">
{/* Left Sidebar - Filters */}
<div className="col-span-3 bg-white rounded-lg shadow p-6">
<h2 className="text-lg font-semibold mb-4">Filters</h2>
<div className="space-y-6">
<div>
<h3 className="text-sm font-medium text-gray-700 mb-2">Companies</h3>
<div className="space-y-2">
{companies.map((company) => (
<button
key={company}
onClick={() => setSelectedCompany(company)}
className={`w-full text-left px-3 py-2 rounded-lg cursor-pointer ${
selectedCompany === company ? 'bg-indigo-50 text-indigo-700' : 'hover:bg-gray-50'
}`}
>
{company}
</button>
))}
</div>
</div>
<div>
<h3 className="text-sm font-medium text-gray-700 mb-2">Location</h3>
<div className="space-y-2">
<label className="flex items-center space-x-2 cursor-pointer">
<input
type="checkbox"
checked={locationFilters.remote}
onChange={() => handleLocationFilter('remote')}
className="rounded text-indigo-600"
/>
<span>Remote</span>
</label>
<label className="flex items-center space-x-2 cursor-pointer">
<input
type="checkbox"
checked={locationFilters.onsite}
onChange={() => handleLocationFilter('onsite')}
className="rounded text-indigo-600"
/>
<span>On-site</span>
</label>
<label className="flex items-center space-x-2 cursor-pointer">
<input
type="checkbox"
checked={locationFilters.hybrid}
onChange={() => handleLocationFilter('hybrid')}
className="rounded text-indigo-600"
/>
<span>Hybrid</span>
</label>
</div>
</div>
</div>
</div>
{/* Main Content */}
<div className="col-span-6">
<div className="bg-white rounded-lg shadow mb-8">
<div className="grid grid-cols-3 gap-4 p-6">
<div ref={barChartRef} className="h-64"></div>
<div ref={pieChartRef} className="h-64"></div>
<div ref={lineChartRef} className="h-64"></div>
</div>
</div>
<div className="space-y-6">
{jobListings.map((job) => (
<div key={job.id} className="bg-white rounded-lg shadow p-6 hover:shadow-lg transition-shadow">
<div className="flex justify-between items-start">
<div>
<h3 className="text-lg font-semibold text-gray-900">{job.title}</h3>
<p className="text-gray-600 mt-1">{job.company}</p>
<div className="flex items-center space-x-4 mt-2">
<span className="text-sm text-gray-500">
<i className="fas fa-map-marker-alt mr-1"></i>
{job.location}
</span>
<span className="text-sm text-gray-500">
<i className="fas fa-clock mr-1"></i>
{job.type}
</span>
<span className="text-sm text-gray-500">
<i className="fas fa-calendar mr-1"></i>
{job.posted}
</span>
</div>
<p className="text-indigo-600 font-medium mt-2">{job.salary}</p>
</div>
<button className="!rounded-button px-4 py-2 bg-indigo-600 text-white hover:bg-indigo-700 cursor-pointer whitespace-nowrap">
Apply Now
</button>
</div>
</div>
))}
</div>
</div>
{/* Right Sidebar - Chatbot */}
<div className="col-span-3">
<div className="bg-white rounded-lg shadow p-6">
<div className="flex items-center justify-between mb-4">
<h2 className="text-lg font-semibold">AI Assistant</h2>
<button
onClick={() => setShowChatbot(!showChatbot)}
className="text-gray-400 hover:text-gray-600 cursor-pointer"
>
<i className={`fas fa-chevron-${showChatbot ? 'down' : 'up'}`}></i>
</button>
</div>
{showChatbot && (
<>
<div className="h-96 overflow-y-auto mb-4 space-y-4">
{chatMessages.map((msg, index) => (
<div
key={index}
className={`flex ${msg.type === 'user' ? 'justify-end' : 'justify-start'}`}
>
<div
className={`max-w-xs rounded-lg px-4 py-2 ${
msg.type === 'user'
? 'bg-indigo-600 text-white'
: 'bg-gray-100 text-gray-800'
}`}
>
{msg.message}
</div>
</div>
))}
</div>
<form onSubmit={handleChatSubmit} className="relative">
<input
type="text"
value={chatInput}
onChange={(e) => setChatInput(e.target.value)}
placeholder="Ask about jobs..."
className="w-full px-4 py-2 border-gray-200 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
/>
<button
type="submit"
className="absolute right-2 top-2 text-indigo-600 hover:text-indigo-700 cursor-pointer"
>
<i className="fas fa-paper-plane"></i>
</button>
</form>
</>
)}
</div>
</div>
</div>
</main>
</div>
);
};
export default App